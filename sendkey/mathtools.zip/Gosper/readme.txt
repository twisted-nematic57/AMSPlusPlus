GOSPER89 0.52 for the TI-89/92+/Voyage 200 by Kevin Kofler
==========================================================

I. Introduction
---------------

This is an implementation of the Gosper summation algorithm. It can compute some
sums the built-in sum operator cannot handle. For example:
gosper89(1/(i^2-1),i,2,n-1)
gosper89(4^k/nCr(2k,k),k,0,n-1)
gosper89(k*k!,k,0,n-1)
However, there are also plenty of sums the built-in sum operator can handle and
GOSPER89 cannot. See section III.

This program does not require any shell or kernel. However, it DOES require
AMS 2.04 or higher. Moreover, if you want to use GOSPER89 in expressions or
programs, you will need IPR (http://membres.lycos.fr/sirryl/), KerNO, DoorsOS,
Universal OS or PreOs.

II. Usage
---------

The program takes 4 arguments:
1) the term of the series you want to sum
2) the summation variable
3) the lower bound of the sum
4) the upper bound of the sum

It returns the sum you asked it to compute when it can be expressed in a "closed
form" (see section III), or throws an error if it can't or if the program is
unable to do so (see sections III and IV).

III. Technical details
----------------------

The Gosper summation algorithm can only handle certain types of sums, called
"hypergeometric series". Hypergeometric series are the series corresponding to
sequences (t[n]) where t[n+1]/t[n] is a rational function in n. Examples are:
- sums of sequences which are polynomials or rational functions in n
- geometric series
- most series involving binomial coefficients (such as nCr(2k,k))
If your series is not hypergeometric, GOSPER89 will throw an "Argument error".

Additionally, in order to be able to do the computations without having to
distinguish between multiple cases, this implementation imposes the following
additional restrictions:
- the powers of the summation variable in the rational function have to be
  constant. For example:
  * gosper89(k^2,k,0,n-1) is OK (t[k+1]/t[k]=(k+1)^2/k^2)
  * gosper89(k^m,k,0,n-1) is NOT OK (t[k+1]/t[k]=(k+1)^m/k^m)
  If this rule is violated, GOSPER89 will throw an "Argument error".
- if x is a root of the numerator of the rational function and y is a root of
  the denominator of the rational function, then x-y has to be constant. For
  example:
  * gosper89((-1)^k*nCr(k,3),k,0,3) is OK:
    t[k+1]/t[k]=(k+1)/(2-k), x=-1, y=2, x-y=-3: constant
  * gosper89((-1)^k*nCr(k,m),k,0,3) is NOT OK:
    t[k+1]/t[k]=(k+1)/(m-1-k), x=-1, y=m-1, x-y=-m: not constant
  If this rule is violated, GOSPER89 will throw a "Too many undefined
  variables" error.

The Gosper algorithm gives a result if and only if the sum can be expressed as
a hypergeometric sequence. In that case, the sum is said to "have a closed
form". Otherwise, GOSPER89 will throw a "No solution found" error.

IV. Error messages
------------------

GOSPER89 throws the following errors:
- "Too few arguments": You did not specify enough arguments. You need to specify
                       4 arguments: the series to sum up, the summation variable,
                       the lower summation bound and the upper summation bound.
- "Too many arguments": You specified too many arguments. You need to specify
                        exactly the 4 arguments listed above, not more.
- "Argument error": The series is not hypergeometric or t[n+1]/t[n] contains
                    variable powers of n.
- "Argument is not a variable name": The given summation variable is not a valid
                                     variable name.
- "Bound": You specified invalid bounds. For example:
           * a lower bound of plus infinity
           * an upper bound of minus infinity
           * an upper bound which is smaller than the lower bound
           * a floating-point number or a fraction as a bound
- "Too many undefined variables": The difference between a root of the numerator
                                  and a root of the denominator is not constant.
- "Overflow": Some of the polynomials used in the computations have an excessive
              degree (256 or higher).
- "No solution found": The requested sum cannot be expressed as a hypergeometric
                       sequence.
- "Internal error": An internal sanity check failed.
In addition, it will forward any errors thrown by the AMS ROM_CALLs it uses to
do the computations. This includes errors such as "Break" or "Memory".

Moreover, GOSPER89 will display a "Questionable accuracy" warning if computations
are done using approximations, because in this case, the solution could be
invalid: due to rounding errors, you can end up with a solution where there is
none.

V. History
----------

v.0.50 (2003-01-25): * Initial public release.
v.0.51 (2003-01-25): * Relicensed under the GPL for inclusion into TIGCC as an
                       example.
                     * Added "too few/many arguments" to the error message
                       documentation.
v.0.52 (2003-02-03): * Now factoring polynomials into complex factors.
                     * Now using cZeros and cSolve instead of zeros and solve.
                     * Handling complex roots correctly when computing the Gosper
                       factorization.
                     * Now displaying a "Questionable accuracy" warning when
                       computations are done using floating point approximations.
                     * Handling infinity as bounds. Taking limits instead of
                       attempting simple substitution for transfinite bounds.
                     * Now checking bound validity.
                     * Forcing AUTO mode when run in EXACT mode, because we
                       need the full factorization.

VI. License
----------

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

VII. Credits
-----------

Thanks to:
- The TIGCC Team (especially Zeljko Juric and Sebastian Reichelt) for TIGCC.
- The GCC developers for GCC.
- Bill Gosper for his summation algorithm.
- Prof. Johann Cigler for explaining the Gosper algorithm in his Discrete
  Mathematics lecture at the University of Vienna.
- Bhuvanesh Bhatt for reporting some glitches in v.0.51 (fixed in 0.52).

VIII. Contact
------------

e-mail: kevin.kofler@chello.at or Kevin@tigcc.ticalc.org
webpage: http://members.chello.at/gerhard.kofler/kevin/ti89prog/