// Gosper89 0.52 - Copyright (C) 2003 Kevin Kofler
// Syntax: gosper89(series,variable,from,to)
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software Foundation,
// Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
// This is a slightly naive implementation of the Gosper summation algorithm.
// Improvements are welcome. Particularly:
// * fix bugs. There might be some bugs. Especially since I am using many
//   functions not documented in TIGCC.
// * make the check for the Gosper conditions more intelligent. It should handle
//   variables assumed to be natural numbers and use a faster algorithm.
// * garbage-collect the expression stack in some way. Currently, much cr*p gets
//   dumped there and stays around until the delete_between at the very end.
// You are free to distribute improved versions on your own under the GPL.
// However, I would appreciate it if you mailed the improvements to me (instead
// of or in addition to releasing them yourself).
//
// To compile version 0.52 of this project, I used:
// * TIGCC 0.94 SP4
// * GCC 3.3-20021230-tigcc-pre7

#define USE_TI89              // Compile for TI-89
#define USE_TI92PLUS          // Compile for TI-92 Plus
#define USE_V200              // Compile for V200

#define RETURN_VALUE          // Return Pushed Expression
#define ENABLE_ERROR_RETURN   // Enable Returning Errors to AMS
#define NO_CALC_DETECT        // We support all 3 models, and use the exact same
                              // code for all of them.

#define MIN_AMS 204           // Compile for AMS 2.04 or higher
#define USE_FLINE_ROM_CALLS

#include <tigcclib.h>         // Include All Header Files


#undef ENABLE_DEBUGGING

#ifdef ENABLE_DEBUGGING
#define SHOW(esi) cmd_pause(esi)
#define WARN(str) ({ST_helpMsg(str);ngetchx();})
#else
#define SHOW(esi) (void)0
#define WARN(str) ST_helpMsg(str)
#endif


// Replace AMS implementations which do not distinguish between x^1.2 and a
// polynomial for some reason.
int IsPolynomialInVar(ESI p,ESI var)
{
  switch (*p) {
    case MINUS_TAG:
      return IsPolynomialInVar(p-1,var);
    case ADD_TAG:
    case SUB_TAG:
    case MUL_TAG:
      return (IsPolynomialInVar(p-1,var)
              &&IsPolynomialInVar(next_expression_index(p-1),var));
    case POW_TAG:
      return (is_independent_of(p,var)||(IsPolynomialInVar(p-1,var)
              &&is_constant(next_expression_index(p-1))&&({
                int y=-1;
                ESI old_estack=top_estack;
                TRY
                  float x=estack_number_to_Float(next_expression_index(p-1));
                  push_Float(x);
                  y=x;
                ONERR
                ENDTRY
                if (y>=0&&!is_Float_exact_whole_number(top_estack)) y=-1;
                top_estack=old_estack;
                y>=0;
              })));
    default:
      return (is_variable(p)||is_independent_of(p,var));
  }
}

// Get the roots of a polynomial into a pointer array - push_czeros is nice, but
// not appropriate for fast access.
void GetRootsOfPolynomial(ESI p, HANDLE h, int *n, ESI var)
{
  push_czeros(p,var);
  ESI q=top_estack-1;
  if (*q==LIST_TAG) ER_throw(ER_TOO_MANY_UNDEFINED);
  while (*q!=END_TAG) {
    HeapReallocThrow(h,(++(*n))<<2);
    ((void**)HeapDeref(h))[(*n-1)]=q;
    q=next_expression_index(q);
  }
}

// Traverse the current expression to find all subexpressions of the form (...)!
// and expand the contents of (...). This is done because AMS will simplify
// (2n+2)!/(2n)!, but not (2(n+1))!/(2n)! for some reason.
// Binomial sums such as gosper89(4^k/nCr(2k,k),k,0,n-1) would fail without this
// function, and this is unacceptable since binomial sums are the main use of
// the Gosper algorithm.
void expand_factorial_contents(ESI p)
{
  ESI o=p,q=next_expression_index(p);
  while (p>q) {
    if (*p==FACTORIAL_TAG) {
      ESI newq=top_estack;
      push_between(q,next_expression_index(p));
      ESI newp=top_estack;
      push_expand(--p,NULL,0);
      push_between(p,o);
      o=top_estack;
      p=newp;q=newq;
    } else if (is_variable(p)||*p==USERFUNC_TAG
               ||(*p>=ARB_REAL_TAG&&*p<=STR_TAG)) {
      p=next_expression_index(p);
    } else if (*p==EXT_TAG||*p==EXT_INSTR_TAG||*p==EXT_SYSTEM_TAG) {
      p-=2;
    } else p--;
  }
  push_internal_simplify(top_estack);
}

// Main Function
void _main(void)
{
  int argc=ArgCount();
  if (argc<4) ER_throw(ER_TOO_FEW_ARGS);
  if (argc>4) ER_throw(ER_TOO_MANY_ARGS);

  unsigned long old_exact=NG_control&8UL;
  NG_control&=~8UL; // We cannot work reliably in EXACT mode, so force AUTO mode.
  TRY // Big TRY...FINALLY...ENDFINAL block - we need to restore NG_control

  // Getting arguments (tn, var, lim1, lim2)
  ESI argptr=top_estack;
  ESI tn=argptr;
  argptr=next_expression_index(argptr);
  ESI var=argptr;
  argptr=next_expression_index(argptr);
  ESI lim1=argptr;
  if (*lim1!=NEGINFINITY_TAG&&is_constant(lim1)&&!is_whole_number(lim1))
    // A constant non-integer lower bound other than -oo is not allowed.
    ER_throw(ER_BOUND);
  argptr=next_expression_index(argptr);
  ESI lim2=argptr;
  if (*lim2!=INFINITY_TAG&&is_constant(lim2)&&!is_whole_number(lim2))
    // A constant non-integer upper bound other than +oo is not allowed.
    ER_throw(ER_BOUND);
  argptr=next_expression_index(argptr)-1;

  // Check if we can determine that lim2<lim1, which is not allowed.
  push_difference(lim2,lim1);
  if (is_negative(top_estack)) ER_throw(ER_BOUND);

  // "Argument is not a variable name"
  if (!is_variable(var)) ER_throw(ER_EXPECTED_VAR);

  // tn+1=tn|n=n+1; rn=tn+1/tn
  push_arg_plus_1(var);
  ESI varp1=top_estack;
  push_substitute_simplify(tn,var,varp1);
  ESI tnp1=top_estack;
  push_reciprocal(tn);
  push_product(tnp1,top_estack);
  unsigned long old_domain=NG_control&1UL;
  NG_control&=~1UL; // Force complex factorization.
  TRY
    push_factor(top_estack,var,0);
  FINALLY
    NG_control|=old_domain;
  ENDFINAL
  expand_factorial_contents(top_estack);
  ESI rn=top_estack;
  SHOW(rn);

  // Make sure rn is a rational function. Otherwise -> "Argument Error".
  push_numerator(rn);
  ESI an=top_estack;
  if (!IsPolynomialInVar(an,var)) ER_throw(ER_ARGUMENT);
  push_denominator(rn);
  ESI bn=top_estack;
  if (!IsPolynomialInVar(bn,var)) ER_throw(ER_ARGUMENT);
  SHOW(an);
  SHOW(bn);

  // Compute Gosper factorization of rn:
  push_expression(((ESQ[]){1,1,POSINT_TAG})+2);
  ESI cn=top_estack;

  // Extract roots.
  try_again:;
  int num_numer_roots=0,num_denom_roots=0;
  HANDLE numer_roots=HeapAllocThrow(0),denom_roots;
  TRY
    GetRootsOfPolynomial(an,numer_roots,&num_numer_roots,var);
    denom_roots=HeapAllocThrow(0);
  ONERR
    HeapFree(numer_roots);
    PASS
  ENDTRY
  TRY
    GetRootsOfPolynomial(bn,denom_roots,&num_denom_roots,var);

  // Check for the Gosper conditions and adjust an, bn and cn accordingly.
    for (int i=0;i<num_numer_roots;i++) {
      for (int j=0;j<num_denom_roots;j++) {
        push_difference(((void**)HeapDeref(denom_roots))[j],
                        ((void**)HeapDeref(numer_roots))[i]);
        // If the difference is complex and the imaginary part is constant, it is
        // not a positive integer.
        if (*top_estack==COMPLEX_TAG && is_constant(top_estack-1)) continue;
        float difference;
        TRY
          difference=estack_number_to_Float(top_estack);
        ONERR
          ER_throw(ER_TOO_MANY_UNDEFINED);
        ENDTRY
        push_Float(difference);
        if (is_Float_exact_whole_number(top_estack)&&(long)difference>=0) {
        // The difference is a positive integer.
          // a(n)=b(n+difference)
          // Divide factors out.
          push_difference(var,((void**)HeapDeref(numer_roots))[i]);
          push_reciprocal(top_estack);
          push_product(an,top_estack);
          // sanity check - throw "Internal error" if it fails
          if (!IsPolynomialInVar(top_estack,var)) ER_throw(ER_ILLEGAL_TAG);
          an=top_estack;
          push_difference(var,((void**)HeapDeref(denom_roots))[j]);
          push_reciprocal(top_estack);
          push_product(bn,top_estack);
          // sanity check - throw "Internal error" if it fails
          if (!IsPolynomialInVar(top_estack,var)) ER_throw(ER_ILLEGAL_TAG);
          bn=top_estack;
          // Now fix cn.
          push_difference(var,((void**)HeapDeref(denom_roots))[j]);
          ESI next_factor=top_estack;
          for (long k=difference;k>0;k--) {
            push_product(cn,next_factor);
            cn=top_estack;
            push_arg_plus_1(next_factor);
            next_factor=top_estack;
          }
          // Restart computations with the new an and bn.
          HeapFree(numer_roots);
          HeapFree(denom_roots);
          ER_success();
          goto try_again;
        }
      }
    }
  FINALLY
    HeapFree(numer_roots);
    HeapFree(denom_roots);
  ENDFINAL

  SHOW(an);
  SHOW(bn);
  SHOW(cn);

  // Compute the degrees of an, bn and cn.
  push_poly_deg_in_var_or_kernel(an,var);
  if (*top_estack!=POSINT_TAG||top_estack[-1]>1) ER_throw(ER_OVERFLOW);
  int dega=GetIntArg(top_estack);

  push_poly_deg_in_var_or_kernel(bn,var);
  if (*top_estack!=POSINT_TAG||top_estack[-1]>1) ER_throw(ER_OVERFLOW);
  int degb=GetIntArg(top_estack);

  push_poly_deg_in_var_or_kernel(cn,var);
  if (*top_estack!=POSINT_TAG||top_estack[-1]>1) ER_throw(ER_OVERFLOW);
  int degc=GetIntArg(top_estack);

  // Compute bn-1.
  push_arg_minus_1(var);
  ESI varm1=top_estack;
  push_substitute_simplify(bn,var,varm1);
  ESI bnm1=top_estack;

  // Compute the degree of xn.
  int degx;
  if (dega==degb) {
    float a,b;
    if (dega) push_nth_derivative(an,var,(ESQ[]){dega,1,POSINT_TAG}+2);
    TRY
      a=estack_number_to_Float(dega?top_estack:an);
    ONERR
      a=NAN;
    ENDTRY
    if (degb) push_nth_derivative(bnm1,var,(ESQ[]){degb,1,POSINT_TAG}+2);
    TRY
      b=estack_number_to_Float(degb?top_estack:bnm1);
    ONERR
      b=NAN;
    ENDTRY
    if (a==b) {
      if (dega) {
        float lambda=a;
        if (dega-1) push_nth_derivative(an,var,(ESQ[]){dega-1,1,POSINT_TAG}+2);
        push_substitute_simplify((dega-1)?top_estack:an,var,
                                 (ESQ[]){0,POSINT_TAG}+1);
        TRY
          a=estack_number_to_Float(top_estack);
        ONERR
          a=NAN;
        ENDTRY
        if (degb-1) push_nth_derivative(bnm1,var,(ESQ[]){degb-1,1,POSINT_TAG}+2);
        push_substitute_simplify((degb-1)?top_estack:bnm1,var,
                                 (ESQ[]){0,POSINT_TAG}+1);
        TRY
          b=estack_number_to_Float(top_estack);
        ONERR
          b=NAN;
        ENDTRY
        lambda=(b-a)*dega/lambda;
        push_Float(lambda);
        if (is_Float_exact_whole_number(top_estack))
          degx=max(degc-dega+1,(int)lambda);
        else
          degx=degc-dega+1;
      } else degx=degc-dega+1;
    } else degx=degc-dega;
  } else degx=degc-max(dega,degb);

  // Make sure the degree makes sense.
  if (degx<0) ER_throw(ER_NO_SOLUTION);
  if (degx>255) ER_throw(ER_OVERFLOW);

  // Solve for xn. an*xn+1-bn-1*xn=cn
  ESI xnvars[degx+1];
  push_END_TAG();
  for (int i=degx;i>=0;i--) {push_next_internal_var(2);xnvars[i]=top_estack;}
  push_LIST_TAG();
  ESI varlist=top_estack;
  push_expression(*xnvars);
  ESI xnindet=top_estack;
  for (int i=1;i<=degx;i++) {
    push_product(xnindet,var);
    push_sum(top_estack,xnvars[i]);
    xnindet=top_estack;
  }
  push_substitute_simplify(xnindet,var,varp1);
  ESI xnp1indet=top_estack;
  push_expression(cn);
  push_expr2_quantum(xnp1indet,an,MUL_TAG);
  push_expr2_quantum(xnindet,bnm1,MUL_TAG);
  push_quantum_pair(SUB_TAG,EQ_TAG);
  ESI polyeq=top_estack;
  SHOW(polyeq);
  push_substitute_simplify(polyeq,var,(ESQ[]){0,POSINT_TAG}+1);
  for (int i=1;i<=degc;i++) {
    push_substitute_simplify(polyeq,var,(ESQ[]){i,1,POSINT_TAG}+2);
    push_quantum(AND_TAG);
  }
  push_csolve(top_estack,varlist);
  if (*top_estack==FALSE_TAG) ER_throw(ER_NO_SOLUTION);
  // If the result contains floating-point numbers, warn about rounding errors.
  int questionable_accuracy=!is_free_of_tag(top_estack,FLOAT_TAG);
  push_expr_quantum(xnindet,WITH_TAG);
  push_internal_simplify(top_estack);
  ESI xn=top_estack;
  SHOW(xn);

  // Deduce sn. sn=bn-1/cn*xn*tn
  push_reciprocal(cn);
  push_product(top_estack,bnm1);
  push_product(top_estack,xn);
  push_product(top_estack,tn);
  ESI sn=top_estack;
  SHOW(sn);

  // Compute and return slim2+1-slim1.
  if (*lim1==NEGINFINITY_TAG) { // lower bound is -oo
    push_lim(sn,var,lim1,(ESQ[]){1,1,POSINT_TAG}+2); // lim sn for var -> -oo +
  } else {
    push_substitute_simplify(sn,var,lim1);
  }
  ESI slim1=top_estack;
  if (*lim2==INFINITY_TAG) { // upper bound is +oo
    push_lim(sn,var,lim2,(ESQ[]){1,1,NEGINT_TAG}+2); // lim sn for var -> +oo -
  } else {
    push_arg_plus_1(lim2);
    push_substitute_simplify(sn,var,top_estack);
  }
  ESI slim2p1=top_estack;
  ESI delete_end=top_estack;
  push_difference(slim2p1,slim1);

  // Clean up the arguments and all the other mess we made on the estack.
  delete_between(argptr,delete_end);

  if (questionable_accuracy) {
    WARN(XR_stringPtr(1509)); // "Questionable accuracy" warning
  }

  FINALLY
    NG_control|=old_exact;
  ENDFINAL
}
